import os
import stat
import pandas as pd
import platform
import sys
import time
import urllib.request
import zipfile
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options



def get_mac_architecture():
    cpu_arch = platform.machine()
    if cpu_arch in ('arm64', 'aarch64'):
        return 'arm64'
    elif cpu_arch in ('x86_64', 'i386'):
        return 'x64'
    else:
        return None
    

def download_chromedriver():
    extract_path = os.path.join(os.path.expanduser('~'), 'Downloads')
    zip_file_name = 'downloaded_file.zip'  # Temporary file name for the zip file

    if os_name == 'Windows':
        download_url = 'https://storage.googleapis.com/chrome-for-testing-public/129.0.6668.91/win64/chromedriver-win64.zip'
    elif os_name == 'Darwin':
        if mac_arch == 'arm64':
            download_url = 'https://storage.googleapis.com/chrome-for-testing-public/129.0.6668.91/mac-arm64/chromedriver-mac-arm64.zip'
        elif mac_arch == 'x64':
            download_url = 'https://storage.googleapis.com/chrome-for-testing-public/129.0.6668.91/mac-x64/chromedriver-mac-x64.zip'
        else:
            print(f'Unsupported Mac architecture: {platform.machine()}')
            sys.exit(1)
    else:
        print(f'Unsupported operating system: {os_name}')
        sys.exit(1)

    # Download the zip file
    zip_file_path = os.path.join(extract_path, zip_file_name)
    try:
        print(f'Downloading from {download_url} to {zip_file_path}...')
        urllib.request.urlretrieve(download_url, zip_file_path)
        print('Download complete.')
    except Exception as e:
        print(f'Error downloading file: {e}')
    

def extract_chromedriver_zip():
    extract_path = os.path.join(os.path.expanduser('~'), 'Downloads')
    zip_file_path = os.path.join(os.path.expanduser('~'), 'Downloads', 'downloaded_file.zip')
    # Extract the zip file
    try:
        print(f'Extracting {zip_file_path} to {extract_path}...')
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
        print('Extraction complete.')
    except Exception as e:
        print(f'Error extracting zip file: {e}')
        sys.exit(1)

    # Remove the temporary zip file
    try:
        os.remove(zip_file_path)
        print('Temporary zip file removed.')
    except Exception as e:
        print(f'Error removing temporary file: {e}')



os_name = platform.system()

if os_name == "Windows":
    chromedriver_path = os.path.join(os.path.expanduser('~'), 'Downloads', 'chromedriver-win64')
    chromedriver_path_full = os.path.join(chromedriver_path, 'chromedriver.exe')
else:
    mac_arch = get_mac_architecture()
    if mac_arch == "x64":
        chromedriver_path = os.path.join(os.path.expanduser('~'), 'Downloads', 'chromedriver-mac-x64')
    else:
        chromedriver_path = os.path.join(os.path.expanduser('~'), 'Downloads', 'chromedriver-mac-arm64')
    chromedriver_path_full = os.path.join(chromedriver_path, 'chromedriver')

if not os.path.exists(chromedriver_path):
    download_chromedriver() 
    extract_chromedriver_zip()

os.chmod(chromedriver_path_full, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)

def yf_financials(tkr, type_="bs"):
    
    def scrape_table():
        "scrape the balance sheet/income statement and return dataframe"
        headers = [header.text for header in driver.find_elements(By.XPATH,  "//div[contains(@class, 'row') and contains(@class, 'yf-1ezv2n5')]//div")]
        table_rows = driver.find_elements(By.XPATH, "//div[starts-with(@class, 'row lv-') and contains(@class, 'yf-1xjz32c')]")
        table_data = [[cell.text for cell in row.find_elements(By.XPATH, ".//div[normalize-space(text())]")] for row in table_rows]
        return pd.DataFrame(data=table_data, columns=headers)
    
    def create_url(tkr):
        url = 'https://finance.yahoo.com/quote/' + tkr
        if type_ == 'is':
            url += '/financials?p='
        elif type_ == 'bs':
            url += '/balance-sheet?p='
        else:
            raise ValueError("Please pass 'bs' or 'is' as type_")
        return url
    
    def click_reject_all():
        # Xpath for reject all button
        reject_all_xpath = "//button[contains(@class, 'btn') and contains(@class, 'secondary') and contains(@class, 'reject-all')]"
        reject_button = driver.find_element(By.XPATH, reject_all_xpath)
        reject_button.click()
        time.sleep(2)

    
    # initialize chrome driver
    if not os.path.isfile(chromedriver_path_full):
        raise FileNotFoundError(f"Chromedriver not found at {chromedriver_path_full}")
    
    chrome_options = Options()
    service = Service(chromedriver_path_full)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    # create list for looping if only one tkr as string 
    if isinstance(tkr, str):
        tkr = [tkr]
    
    df_all = pd.DataFrame() # dataframe to combine all table data
    for i, tkr_ in enumerate(tkr):
        url = create_url(tkr_)
        driver.get(url)
        time.sleep(1.5) 
        
        if i == 0:
            click_reject_all()
        
        df = scrape_table()
        df = df.transpose()
        df.columns = df.iloc[0, :]
        df = df.iloc[1:, :]
        df.insert(0, "comp", tkr_)
        for col in [column for column in df.columns if column != "comp"]:
            df[col] = (
                df[col]
                .str.replace(",", "", regex=True)
                .str.replace("--", "")
                .replace({"": np.nan})
                .astype(float)
                )

        df_all = pd.concat([df_all, df])
    
    # Close the browser
    driver.quit()
    return df_all

